<!DOCTYPE html>
<html>
<head>
	<title>Leolocalizacion</title>
	 <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">

  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>

<link rel="icon" href="icono.ico"
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <style type="text/css">
   .button {
          background-color: blue;
          border: none;
          color: blue;
          padding: 20px;
          text-align: center;
          text-decoration: none;
          display: inline-block;
          font-size: 16px;
          margin: 4px 2px;
      }

      .button5 {border-radius: 50%;
         background-color: white;}
      

  *{
        margin: 0px;
        padding: 0px;

      }

div#barra{
     margin: auto;
      
        background-color: powderblue;

}

  </style>

</head>
<body>
  <div id="barra" class="tap-sport-tools" style="width:auto; height:auto;">
    <center> <img class="img-responsive" src="logo.png" width="300" /> </center>
  </div>
	<form method="POST" action="opc_usuario.php" >
	   <center>
	   	<br></br><center></center> <br></br>
      <div class="container" style="width:500px; padding:3px;">     
       <div class="row" style="float: right;">
       <div class="col-xs-12 col-sm-6 col-md-8"> 
            <button type="submit" class="button5" name="btn_libros"><img class="img-responsive" src="material.png" alt="x" width="200" /></button>
            <br>
            <input type="submit" value="Buscar material bibliográfico" class="btn btn-success" name="btn_libros">
            <br> </br>
          </div>
        </div>
        <div class="row" style="float: left">
          <div class="col-xs-12 col-sm-6 col-md-8">
            <button type="submit" class="button5" name="btn_lugares"><img class="img-responsive" src="lugares.png" alt="x" width="200" /></button>
            <br>
            <input type="submit" value="Buscar lugares" class="btn btn-primary" name="btn_lugares"> 
         </div>
       </div>
           <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>   <br>  <br>
         <input type="submit" value="Atrás" class="btn btn-info" name="btn_atras">  
      </div>
      <br>
    </center>


       
     
</form>
    <?php
     if(isset($_POST['btn_libros']))
      {      
        header ("Location: usuario.php");
      }
      if(isset($_POST['btn_lugares']))
      {   
         header ("Location: lugares.php");
      }if(isset($_POST['btn_atras']))
      {   
         header ("Location: inicio.php");
      }
      ?>
</body>
</html>