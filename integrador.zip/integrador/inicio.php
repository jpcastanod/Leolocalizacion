<!DOCTYPE html>
<html>
<head>
	<title>Leolocalizacion</title>
	 <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">

  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  <link rel="icon" href="icono.ico"
   <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css"> 

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <style type="text/css">
      .button {
          background-color: blue;
          border: none;
          color: blue;
          padding: 20px;
          text-align: center;
          text-decoration: none;
          display: inline-block;
          font-size: 16px;
          margin: 4px 2px;
      }

      .button5 {border-radius: 50%;
         background-color: white;}
      

      *{
        margin: 0px;
        padding: 0px;

      }
      div#general{
        margin: auto;
        width: 900px;
        height: 1000px;
        background-color: rgba(95,232,256,0.8);

      }

      h1{
          font-family: "Homer Simpson", cursive;
          font-size: 2vw;
        }
        </style>
      </head>


<body background="biblioteca.jpg" class="img-responsive">
  <br>
  <div class="row""
    <div id= "general" class="col-xs-12 col-sm-6 col-md-8" style="width:55%; height:auto;">
       <div id="logo" style="position:absolute; width:auto; "> 
            <img class="img-responsive" src="eafit.png" width="100" > </div>
     <center> <img class="img-responsive" src="logo.png" width="400" /> </center>
     <form method="POST" action="inicio.php" >
	     <center>
	       <center><h1 style="color:white;">INGRESAR COMO:</h1></center> <br></br>
         <div> 
            <center><button type="submit" class="button5" name="btn_usuario"><img class="img-responsive" src="usuario2.png" alt="x" width="200" /></button></center>
            <br>
            <input type="submit" value="Usuario" class="btn btn-success" name="btn_usuario">
            <br> </br>
         
        </div>
   
         <div>
            <button type="submit" class="button5" name="btn_adm"><img class="img-responsive" src="admin.png" alt="x" width="200" /></button>
            <br>
            <input type="submit" value="Administrador" class="btn btn-primary" name="btn_adm">  
         </div>
       </div>
         <br>
         <br>
       </center>
    </div> 
  </div>
    <br>  
    </form>

    <?php
     if(isset($_POST['btn_usuario']))
      {      
        header ("Location: opc_usuario.php");
      }
      if(isset($_POST['btn_adm']))
      {   
        header ("Location: autentificacion.php");
      }
      ?>

</body>
</html>