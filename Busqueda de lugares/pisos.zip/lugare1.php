
<!DOCTYPE html>
<html>
<head>
  <title> Leolocalizacion </title>
   <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">

  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
<link rel="icon" href="icono.ico"
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <style type="text/css">

  div#barra{
     margin: auto;
      
        background-color: powderblue;

}
</style>
</head>


<body>

  <div id="barra" class="tap-sport-tools" style="width:auto; height:auto;">
    <center> <img class="img-responsive" src="logo.png" width="300" /> </center>
  </div>
  <form method="POST" action="lugare1.php">
    <center>
      <center></center> <br></br> 
      <div class="form-group">
    <select name="lugar" class="form-control"> 
      <option> --Seleccione una opción-- </option>
      <option value= "1"> 1.Gestion de recursos de información </option>
      <option value= "2"> 2.Comunicaciones </option>
      <option value= "3"> 3.Secretaría dirección</option>
      <option value= "4"> 4.Jefatura del Centro Cultural Biblioteca </option>
      <option value= "5"> 5.Dirección del Centro Cultural Biblioteca  </option>
      <option value= "6"> 6.Esquina del trueque literario permanente</option>
      <option value= "7"> 7.Sala de audiovisuasles </option>
      <option value= "8"> 8.Tesis y proyectos de grado </option>
      <option value= "9"> 9.Centro de artes </option>
      <option value= "10"> 10.Ingreso a la Torre Técnica del Centro Cultural Biblioteca</option>
      <option value= "11"> 11.Asesoría y préstamo de audiovisuales </option>
      <option value= "12"> 12.Orientacion a usuarios </option>
      <option value= "13"> 13.Salas de estudio grupal </option>
      <option value= "14"> 14.Área de estudio individual  </option>
      <option value= "15"> 15.Cátalogo en línea </option>
      <option value= "16"> 16.Recomendados </option>
      <option value= "17"> 17.Baños públicos </option>
      <option value= "18"> 18.Desarrollo de colecciones </option>
      <option value= "19"> 19.Coordinación de gestión de Recursos de Información</option>
      <option value= "20"> 20.Gestión tecnológica y proyectos </option>
      <option value= "21"> 21.Coordinacion de servicios al público </option>
      <option value= "22"> 22.Sala de reuniones</option>
      <option value= "23"> 23.Bodega </option>
      <option value= "24"> 24.Cocineta </option>
      <option value= "25"> 25.Punto de café </option>
      <option value= "26"> 26.Ascensores </option>
      <option value= "27"> 27.Escaleras </option>
      <option value= "28"> 28.Baños públicos </option>
      <option value= "29"> 29.Teléfono público </option>
    </select>
  </div>
    <input type="submit" value="localizar" class="btn btn-primary" name="btn_localizar">
    <input type="submit" value="Atrás" class="btn btn-info" name="btn_atras">

  </center>
</form>
</form>
    <?php
     if(isset($_POST['btn_localizar']))
      {      
        $lugar = $_POST['lugar'];

        if($lugar=="1"){
          ?>
          <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-1.png"> '?></td>
        </center>
          <?php
        }
        if($lugar=="2"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-2-3-4-5.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="3"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-2-3-4-5.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="4"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-2-3-4-5.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="5"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-2-3-4-5.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="6"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-6.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="7"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-7.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="8"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-8.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="9"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-9.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="10"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-10.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="11"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-11.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="12"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-12.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="13"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-13.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="14"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-14.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="15"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-15.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="16"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-16.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="17"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-17.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="18"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-18-19-20-21.png"> '?></td>
        </center>
          <?php
        } 
          if($lugar=="19"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-18-19-20-21.png"> '?></td>
        </center>
          <?php
        }
          if($lugar=="20"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-18-19-20-21.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="21"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-18-19-20-21.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="22"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-22.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="23"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-23.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="24"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-24.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="25"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-25.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="26"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-10.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="27"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-10.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="28"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-10.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="29"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso1-10.png"> '?></td>
        </center>
          <?php
        }
      }if(isset($_POST['btn_atras']))
      { header ("Location:lugares.php");
    }
      ?>
</body>
</html>