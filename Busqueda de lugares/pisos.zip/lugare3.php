
<!DOCTYPE html>
<html>
<head>
  <title> Leolocalizacion </title>
   <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">

  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
<link rel="icon" href="icono.ico"
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <style type="text/css">

  div#barra{
     margin: auto;
      
        background-color: powderblue;

}
</style>
</head>


<body>

  <div id="barra" class="tap-sport-tools" style="width:auto; height:auto;">
    <center> <img class="img-responsive" src="logo.png" width="300" /> </center>
  </div>
  <form method="POST" action="lugare3.php">
    <center>
      <center></center> <br></br> 
      <div class="form-group">
    <select name="lugar" class="form-control"> 
      <option> --Seleccione una opción-- </option>
      <option value= "1"> 1.Catalogo en línea SINBAD </option>
      <option value= "2"> 2.Fotocopias y servicios de impresión </option>
      <option value= "3"> 3.Sala de Consulta</option>
      <option value= "4"> 4.Barra de Consulta </option>
      <option value= "5"> 5.Mezanine de computadores para estudio grupal </option>
      <option value= "6"> 6.Cubículos para investigadores</option>
      <option value= "7"> 7.Referencia </option>
      <option value= "8"> 8.Colecciones de Informes y Balances; Normas Técnicas; Catálogos Industriales, Documentos (CEDO- CEMDOC)*</option>
      <option value= "9"> 9.Hemeroteca General </option>
      <option value= "10"> 10.Hemeroteca General(Mezanine)</option>
      <option value= "11"> 11.Sala de audición musical </option>
      <option value= "12"> 12.Sala de formación de usuarios- COIN- </option>
      <option value= "13"> 13.Ascensores </option>
      <option value= "14"> 14.Escaleras </option>
      <option value= "15"> 15.Baños públicos </option>
      <option value= "16"> 16.Teléfono público </option>
    </select>
  </div>
    <input type="submit" value="localizar" class="btn btn-primary" name="btn_localizar">
    <input type="submit" value="Atrás" class="btn btn-info" name="btn_atras">

  </center>
</form>
</form>
    <?php
     if(isset($_POST['btn_localizar']))
      {      
        $lugar = $_POST['lugar'];

        if($lugar=="1"){
          ?>
          <center>
          <td><?php echo ' <img class="img-responsive" src="piso3-1.png"> '?></td>
        </center>
          <?php
        }
        if($lugar=="2"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso3-2.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="3"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso3-3.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="4"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso3-4.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="5"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso3-5.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="6"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso3-6.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="7"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso3-7.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="8"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso3-8.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="9"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso3-9.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="10"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso3-10.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="11"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso3-11.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="12"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso3-12.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="13"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso3-13.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="14"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso3-13.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="15"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso3-13.png"> '?></td>
        </center>
          <?php
        }
         if($lugar=="16"){
          ?>
           <center>
          <td><?php echo ' <img class="img-responsive" src="piso3-13.png"> '?></td>
        </center>
          <?php
        }
      }if(isset($_POST['btn_atras']))
      { header ("Location:lugares.php");
    }
      ?>
</body>
</html>